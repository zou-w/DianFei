package com.example.revisedianfei.BeizhuServer;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.example.revisedianfei.HuikuanServer.HuikuanData;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BeizhuListener extends AnalysisEventListener<BeizhuData> {
    private static final Logger log = LoggerFactory.getLogger(BeizhuListener.class);
    private final List<BeizhuData> beizhuDataList = new ArrayList();
    private final List<HuikuanData> huikuanDataList;
    private final List<TempBeizhuData1> yishoulist = new ArrayList();
    private final List<TempBeizhuData2> weishoulist = new ArrayList();
    private final List<HuikuanData> yushoulist = new ArrayList();
    private final List<HuikuanData> yiweishoulist = new ArrayList();

    public BeizhuListener(List<HuikuanData> huikuanDataList) {
        this.huikuanDataList = huikuanDataList;
    }

    public void invoke(BeizhuData beizhuData, AnalysisContext context) {
        for(int i = 0; i < this.huikuanDataList.size(); ++i) {
            if (beizhuData.getGdfs().equals("直供电") && ((HuikuanData)this.huikuanDataList.get(i)).getSfzgd().equals("是")) {
                if (((HuikuanData)this.huikuanDataList.get(i)).getYys() != null && ((HuikuanData)this.huikuanDataList.get(i)).getYys().equals(beizhuData.getFtcs()) && ((HuikuanData)this.huikuanDataList.get(i)).getHh() != null && ((HuikuanData)this.huikuanDataList.get(i)).getHh().equals(beizhuData.getHh()) && ((HuikuanData)this.huikuanDataList.get(i)).getQsds() != null && ((HuikuanData)this.huikuanDataList.get(i)).getJzds() != null) {
                    if (!(beizhuData.getZd() <= ((HuikuanData)this.huikuanDataList.get(i)).getQsds()) && !(beizhuData.getQd() >= ((HuikuanData)this.huikuanDataList.get(i)).getJzds())) {
                        if (beizhuData.getZd() <= ((HuikuanData)this.huikuanDataList.get(i)).getJzds()) {
                            if (beizhuData.getZd() < ((HuikuanData)this.huikuanDataList.get(i)).getJzds()) {
                                HuikuanData huikuanData = (HuikuanData)this.huikuanDataList.get(i);
                                huikuanData.setQsds(beizhuData.getZd());
                                huikuanData.setDd(huikuanData.getJzds() - huikuanData.getQsds());
                                huikuanData.setYjsje(huikuanData.getDd() / ((HuikuanData)this.huikuanDataList.get(i)).getDd() * ((HuikuanData)this.huikuanDataList.get(i)).getYjsje());
                                this.yushoulist.add(huikuanData);
                            }

                            if (beizhuData.getQd() >= ((HuikuanData)this.huikuanDataList.get(i)).getQsds()) {
                                double a = ((HuikuanData)this.huikuanDataList.get(i)).getYdgxbl() - beizhuData.getFtbl();
                                if (a >= -0.03) {
                                    beizhuData.setBz("本月已收");
                                } else {
                                    beizhuData.setBz("本月已收+未收（比例）");
                                    this.yiweishoulist.add((HuikuanData)this.huikuanDataList.get(i));
                                }
                            } else {
                                beizhuData.setBz("之前已收+本月已收");
                            }
                        } else if (beizhuData.getQd() >= ((HuikuanData)this.huikuanDataList.get(i)).getQsds()) {
                            beizhuData.setBz("本月已收+未收（度数）");
                            this.yiweishoulist.add((HuikuanData)this.huikuanDataList.get(i));
                        } else {
                            beizhuData.setBz("之前已收+本月已收+未收（度数）");
                            this.yiweishoulist.add((HuikuanData)this.huikuanDataList.get(i));
                        }
                    } else {
                        if (beizhuData.getZd() >= ((HuikuanData)this.huikuanDataList.get(i)).getJzds()) {
                            beizhuData.setBz("未收（度数）");
                        }

                        if (beizhuData.getZd() <= ((HuikuanData)this.huikuanDataList.get(i)).getJzds()) {
                            beizhuData.setBz("之前已收");
                            this.yushoulist.add((HuikuanData)this.huikuanDataList.get(i));
                        }
                    }
                }
            } else if (beizhuData.getGdfs().equals("转供电") && ((HuikuanData)this.huikuanDataList.get(i)).getSfzgd().equals("否") && ((HuikuanData)this.huikuanDataList.get(i)).getYys() != null && ((HuikuanData)this.huikuanDataList.get(i)).getYys().equals(beizhuData.getFtcs()) && ((HuikuanData)this.huikuanDataList.get(i)).getDb() != null && ((HuikuanData)this.huikuanDataList.get(i)).getDb().equals(beizhuData.getDb()) && ((HuikuanData)this.huikuanDataList.get(i)).getQsds() != null && ((HuikuanData)this.huikuanDataList.get(i)).getJzds() != null) {
                if (!(beizhuData.getZd() <= ((HuikuanData)this.huikuanDataList.get(i)).getQsds()) && !(beizhuData.getQd() >= ((HuikuanData)this.huikuanDataList.get(i)).getJzds())) {
                    if (beizhuData.getZd() <= ((HuikuanData)this.huikuanDataList.get(i)).getJzds()) {
                        if (beizhuData.getZd() < ((HuikuanData)this.huikuanDataList.get(i)).getJzds()) {
                            HuikuanData huikuanData = (HuikuanData)this.huikuanDataList.get(i);
                            huikuanData.setQsds(beizhuData.getZd());
                            huikuanData.setDd(huikuanData.getJzds() - huikuanData.getQsds());
                            huikuanData.setYjsje(huikuanData.getDd() / ((HuikuanData)this.huikuanDataList.get(i)).getDd() * ((HuikuanData)this.huikuanDataList.get(i)).getYjsje());
                            this.yushoulist.add(huikuanData);
                        }

                        if (beizhuData.getQd() >= ((HuikuanData)this.huikuanDataList.get(i)).getQsds()) {
                            double a = beizhuData.getFtbl() - ((HuikuanData)this.huikuanDataList.get(i)).getYdgxbl();
                            if (a >= -0.03) {
                                beizhuData.setBz("本月已收");
                            } else {
                                beizhuData.setBz("本月已收+未收（比例）");
                                this.yiweishoulist.add((HuikuanData)this.huikuanDataList.get(i));
                            }
                        } else {
                            beizhuData.setBz("之前已收+本月已收");
                        }
                    } else if (beizhuData.getQd() >= ((HuikuanData)this.huikuanDataList.get(i)).getQsds()) {
                        beizhuData.setBz("本月已收+未收（度数）");
                        this.yiweishoulist.add((HuikuanData)this.huikuanDataList.get(i));
                    } else {
                        beizhuData.setBz("之前已收+本月已收+未收（度数）");
                        this.yiweishoulist.add((HuikuanData)this.huikuanDataList.get(i));
                    }
                } else {
                    if (beizhuData.getZd() >= ((HuikuanData)this.huikuanDataList.get(i)).getJzds()) {
                        beizhuData.setBz("未收（度数）");
                    }

                    if (beizhuData.getZd() <= ((HuikuanData)this.huikuanDataList.get(i)).getJzds()) {
                        beizhuData.setBz("之前已收");
                        this.yushoulist.add((HuikuanData)this.huikuanDataList.get(i));
                    }
                }
            }
        }

        TempBeizhuData1 tempBeizhuData1 = new TempBeizhuData1();
        TempBeizhuData2 tempBeizhuData2 = new TempBeizhuData2();
        if (beizhuData.getBz() != null && !beizhuData.getBz().equals("未收（度数）")) {
            if (!beizhuData.getBz().equals("本月已收") && !beizhuData.getBz().equals("之前已收") && !beizhuData.getBz().equals("之前已收+本月已收")) {
                for(int j = 0; j < this.yiweishoulist.size(); ++j) {
                    if (beizhuData.getGdfs().equals("直供电") && ((HuikuanData)this.yiweishoulist.get(j)).getSfzgd().equals("是")) {
                        if (((HuikuanData)this.yiweishoulist.get(j)).getYys() != null && ((HuikuanData)this.yiweishoulist.get(j)).getYys().equals(beizhuData.getFtcs()) && ((HuikuanData)this.yiweishoulist.get(j)).getHh() != null && ((HuikuanData)this.yiweishoulist.get(j)).getHh().equals(beizhuData.getHh()) && ((HuikuanData)this.yiweishoulist.get(j)).getQsds() != null && ((HuikuanData)this.yiweishoulist.get(j)).getJzds() != null) {
                            if (beizhuData.getQd() >= ((HuikuanData)this.yiweishoulist.get(j)).getQsds() && beizhuData.getZd() <= ((HuikuanData)this.yiweishoulist.get(j)).getJzds()) {
                                this.addBeizhuData1(beizhuData, tempBeizhuData1);
                                tempBeizhuData1.setFtbl(((HuikuanData)this.yiweishoulist.get(j)).getYdgxbl());
                                tempBeizhuData1.setFtje(tempBeizhuData1.getYsdf() * tempBeizhuData1.getFtbl());
                                tempBeizhuData1.setBz("本月已收");
                                this.yishoulist.add(tempBeizhuData1);
                                this.addBeizhuData2(beizhuData, tempBeizhuData2);
                                tempBeizhuData2.setFtbl(beizhuData.getFtbl() - ((HuikuanData)this.yiweishoulist.get(j)).getYdgxbl());
                                tempBeizhuData2.setFtje(tempBeizhuData2.getYsdf() * tempBeizhuData2.getFtbl());
                                tempBeizhuData2.setBz("未收（比例）");
                                this.weishoulist.add(tempBeizhuData2);
                            } else {
                                this.addBeizhuData1(beizhuData, tempBeizhuData1);
                                tempBeizhuData1.setZd(((HuikuanData)this.yiweishoulist.get(j)).getJzds());
                                tempBeizhuData1.setZfdl(tempBeizhuData1.getZd() - tempBeizhuData1.getQd());
                                tempBeizhuData1.setFtje(tempBeizhuData1.getZfdl() / beizhuData.getZfdl() * beizhuData.getFtje());
                                if (tempBeizhuData1.getQd() < ((HuikuanData)this.yiweishoulist.get(j)).getQsds()) {
                                    tempBeizhuData1.setBz("之前已收+本月已收");
                                } else {
                                    tempBeizhuData1.setBz("本月已收");
                                }

                                this.yishoulist.add(tempBeizhuData1);
                                this.addBeizhuData2(beizhuData, tempBeizhuData2);
                                tempBeizhuData2.setQd(((HuikuanData)this.yiweishoulist.get(j)).getJzds());
                                tempBeizhuData2.setZfdl(tempBeizhuData2.getZd() - tempBeizhuData2.getQd());
                                tempBeizhuData2.setFtje(tempBeizhuData2.getZfdl() / beizhuData.getZfdl() * beizhuData.getFtje());
                                tempBeizhuData2.setBz("未收（度数）");
                                this.weishoulist.add(tempBeizhuData2);
                            }
                        }
                    } else if (beizhuData.getGdfs().equals("转供电") && ((HuikuanData)this.yiweishoulist.get(j)).getSfzgd().equals("否") && ((HuikuanData)this.yiweishoulist.get(j)).getYys() != null && ((HuikuanData)this.yiweishoulist.get(j)).getYys().equals(beizhuData.getFtcs()) && ((HuikuanData)this.yiweishoulist.get(j)).getDb() != null && ((HuikuanData)this.yiweishoulist.get(j)).getDb().equals(beizhuData.getDb()) && ((HuikuanData)this.yiweishoulist.get(j)).getQsds() != null && ((HuikuanData)this.yiweishoulist.get(j)).getJzds() != null) {
                        if (beizhuData.getQd() >= ((HuikuanData)this.yiweishoulist.get(j)).getQsds() && beizhuData.getZd() <= ((HuikuanData)this.yiweishoulist.get(j)).getJzds()) {
                            this.addBeizhuData1(beizhuData, tempBeizhuData1);
                            tempBeizhuData1.setFtbl(((HuikuanData)this.yiweishoulist.get(j)).getYdgxbl());
                            tempBeizhuData1.setFtje(tempBeizhuData1.getYsdf() * tempBeizhuData1.getFtbl());
                            tempBeizhuData1.setBz("本月已收");
                            this.yishoulist.add(tempBeizhuData1);
                            this.addBeizhuData2(beizhuData, tempBeizhuData2);
                            tempBeizhuData2.setFtbl(beizhuData.getFtbl() - ((HuikuanData)this.yiweishoulist.get(j)).getYdgxbl());
                            tempBeizhuData2.setFtje(tempBeizhuData2.getYsdf() * tempBeizhuData2.getFtbl());
                            tempBeizhuData2.setBz("未收（比例）");
                            this.weishoulist.add(tempBeizhuData2);
                        } else {
                            this.addBeizhuData1(beizhuData, tempBeizhuData1);
                            tempBeizhuData1.setZd(((HuikuanData)this.yiweishoulist.get(j)).getJzds());
                            tempBeizhuData1.setZfdl(tempBeizhuData1.getZd() - tempBeizhuData1.getQd());
                            tempBeizhuData1.setFtje(tempBeizhuData1.getZfdl() / beizhuData.getZfdl() * beizhuData.getFtje());
                            if (tempBeizhuData1.getQd() < ((HuikuanData)this.yiweishoulist.get(j)).getQsds()) {
                                tempBeizhuData1.setBz("之前已收+本月已收");
                            } else {
                                tempBeizhuData1.setBz("本月已收");
                            }

                            this.yishoulist.add(tempBeizhuData1);
                            this.addBeizhuData2(beizhuData, tempBeizhuData2);
                            tempBeizhuData2.setQd(((HuikuanData)this.yiweishoulist.get(j)).getJzds());
                            tempBeizhuData2.setZfdl(tempBeizhuData2.getZd() - tempBeizhuData2.getQd());
                            tempBeizhuData2.setFtje(tempBeizhuData2.getZfdl() / beizhuData.getZfdl() * beizhuData.getFtje());
                            tempBeizhuData2.setBz("未收（度数）");
                            this.weishoulist.add(tempBeizhuData2);
                        }
                    }
                }
            } else {
                this.addBeizhuData1(beizhuData, tempBeizhuData1);
                this.yishoulist.add(tempBeizhuData1);
            }
        } else {
            this.addBeizhuData2(beizhuData, tempBeizhuData2);
            this.weishoulist.add(tempBeizhuData2);
        }

        this.beizhuDataList.add(beizhuData);
        System.out.println("过程中处理数据条数：" + this.beizhuDataList.size());
    }

    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
    }

    public BeizhuStats getBeizhuStats() {
        return new BeizhuStats(this.beizhuDataList);
    }

    public TempBeizhuData1 addBeizhuData1(BeizhuData beizhuData, TempBeizhuData1 tempBeizhuData1) {
        tempBeizhuData1.setFtcs(beizhuData.getFtcs());
        tempBeizhuData1.setQy(beizhuData.getQy());
        tempBeizhuData1.setZdmc(beizhuData.getZdmc());
        tempBeizhuData1.setTtzdbm(beizhuData.getTtzdbm());
        tempBeizhuData1.setHh(beizhuData.getHh());
        tempBeizhuData1.setDb(beizhuData.getDb());
        tempBeizhuData1.setQd(beizhuData.getQd());
        tempBeizhuData1.setZd(beizhuData.getZd());
        tempBeizhuData1.setKssj(beizhuData.getKssj());
        tempBeizhuData1.setJssj(beizhuData.getJssj());
        tempBeizhuData1.setZfsj(beizhuData.getZfsj());
        tempBeizhuData1.setZfdl(beizhuData.getZfdl());
        tempBeizhuData1.setYdje(beizhuData.getYdje());
        tempBeizhuData1.setGdfs(beizhuData.getGdfs());
        tempBeizhuData1.setYsdf(beizhuData.getYsdf());
        tempBeizhuData1.setFtbl(beizhuData.getFtbl());
        tempBeizhuData1.setFtje(beizhuData.getFtje());
        tempBeizhuData1.setBz(beizhuData.getBz());
        return tempBeizhuData1;
    }

    public TempBeizhuData2 addBeizhuData2(BeizhuData beizhuData, TempBeizhuData2 tempBeizhuData2) {
        tempBeizhuData2.setFtcs(beizhuData.getFtcs());
        tempBeizhuData2.setQy(beizhuData.getQy());
        tempBeizhuData2.setZdmc(beizhuData.getZdmc());
        tempBeizhuData2.setTtzdbm(beizhuData.getTtzdbm());
        tempBeizhuData2.setHh(beizhuData.getHh());
        tempBeizhuData2.setDb(beizhuData.getDb());
        tempBeizhuData2.setQd(beizhuData.getQd());
        tempBeizhuData2.setZd(beizhuData.getZd());
        tempBeizhuData2.setKssj(beizhuData.getKssj());
        tempBeizhuData2.setJssj(beizhuData.getJssj());
        tempBeizhuData2.setZfsj(beizhuData.getZfsj());
        tempBeizhuData2.setZfdl(beizhuData.getZfdl());
        tempBeizhuData2.setYdje(beizhuData.getYdje());
        tempBeizhuData2.setGdfs(beizhuData.getGdfs());
        tempBeizhuData2.setYsdf(beizhuData.getYsdf());
        tempBeizhuData2.setFtbl(beizhuData.getFtbl());
        tempBeizhuData2.setFtje(beizhuData.getFtje());
        tempBeizhuData2.setBz(beizhuData.getBz());
        return tempBeizhuData2;
    }

    public List<BeizhuData> getBeizhuDataList() {
        return this.beizhuDataList;
    }

    public List<HuikuanData> getHuikuanDataList() {
        return this.huikuanDataList;
    }

    public List<TempBeizhuData1> getYishoulist() {
        return this.yishoulist;
    }

    public List<TempBeizhuData2> getWeishoulist() {
        return this.weishoulist;
    }

    public List<HuikuanData> getYushoulist() {
        return this.yushoulist;
    }

    public List<HuikuanData> getYiweishoulist() {
        return this.yiweishoulist;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof BeizhuListener)) {
            return false;
        } else {
            BeizhuListener other = (BeizhuListener)o;
            if (!other.canEqual(this)) {
                return false;
            } else {
                Object this$beizhuDataList = this.getBeizhuDataList();
                Object other$beizhuDataList = other.getBeizhuDataList();
                if (this$beizhuDataList == null) {
                    if (other$beizhuDataList != null) {
                        return false;
                    }
                } else if (!this$beizhuDataList.equals(other$beizhuDataList)) {
                    return false;
                }

                Object this$huikuanDataList = this.getHuikuanDataList();
                Object other$huikuanDataList = other.getHuikuanDataList();
                if (this$huikuanDataList == null) {
                    if (other$huikuanDataList != null) {
                        return false;
                    }
                } else if (!this$huikuanDataList.equals(other$huikuanDataList)) {
                    return false;
                }

                Object this$yishoulist = this.getYishoulist();
                Object other$yishoulist = other.getYishoulist();
                if (this$yishoulist == null) {
                    if (other$yishoulist != null) {
                        return false;
                    }
                } else if (!this$yishoulist.equals(other$yishoulist)) {
                    return false;
                }

                Object this$weishoulist = this.getWeishoulist();
                Object other$weishoulist = other.getWeishoulist();
                if (this$weishoulist == null) {
                    if (other$weishoulist != null) {
                        return false;
                    }
                } else if (!this$weishoulist.equals(other$weishoulist)) {
                    return false;
                }

                Object this$yushoulist = this.getYushoulist();
                Object other$yushoulist = other.getYushoulist();
                if (this$yushoulist == null) {
                    if (other$yushoulist != null) {
                        return false;
                    }
                } else if (!this$yushoulist.equals(other$yushoulist)) {
                    return false;
                }

                Object this$yiweishoulist = this.getYiweishoulist();
                Object other$yiweishoulist = other.getYiweishoulist();
                if (this$yiweishoulist == null) {
                    if (other$yiweishoulist != null) {
                        return false;
                    }
                } else if (!this$yiweishoulist.equals(other$yiweishoulist)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof BeizhuListener;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $beizhuDataList = this.getBeizhuDataList();
        result = result * 59 + ($beizhuDataList == null ? 43 : $beizhuDataList.hashCode());
        Object $huikuanDataList = this.getHuikuanDataList();
        result = result * 59 + ($huikuanDataList == null ? 43 : $huikuanDataList.hashCode());
        Object $yishoulist = this.getYishoulist();
        result = result * 59 + ($yishoulist == null ? 43 : $yishoulist.hashCode());
        Object $weishoulist = this.getWeishoulist();
        result = result * 59 + ($weishoulist == null ? 43 : $weishoulist.hashCode());
        Object $yushoulist = this.getYushoulist();
        result = result * 59 + ($yushoulist == null ? 43 : $yushoulist.hashCode());
        Object $yiweishoulist = this.getYiweishoulist();
        result = result * 59 + ($yiweishoulist == null ? 43 : $yiweishoulist.hashCode());
        return result;
    }

    public String toString() {
        return "BeizhuListener(beizhuDataList=" + this.getBeizhuDataList() + ", huikuanDataList=" + this.getHuikuanDataList() + ", yishoulist=" + this.getYishoulist() + ", weishoulist=" + this.getWeishoulist() + ", yushoulist=" + this.getYushoulist() + ", yiweishoulist=" + this.getYiweishoulist() + ")";
    }
}
