package com.example.revisedianfei;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
}
